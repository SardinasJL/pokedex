<?php $__env->startSection("content"); ?>

    <div class="container col-md-10">
        <div class="card">
            <div class="card-header">
                Nuevo pokemon
            </div>
            <div class="card-body">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route("pokemons.store")); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre</label>
                        <input type="text" id="nombre" name="nombre" value="<?php echo e(old("nombre")); ?>" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="peso" class="form-label">Peso</label>
                        <input type="text" id="peso" name="peso" value="<?php echo e(old("peso")); ?>" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="altura" class="form-label">Altura</label>
                        <input type="text" id="altura" name="altura" value="<?php echo e(old("altura")); ?>" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="tipos_id" class="form-label">Tipo</label>
                        <select name="tipos_id" id="tipos_id" class="form-select">
                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tipo->id); ?>" <?php echo e($tipo->id==old("tipos_id")?"selected":""); ?>>
                                    <?php echo e($tipo->descripcion); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="foto" class="form-label">Foto</label>
                        <input type="file" id="foto" name="foto" class="form-control">
                    </div>
                    <div class="text-center">
                        <button class="btn btn-primary">Guardar</button>
                        <a href="<?php echo e(route("pokemons.index")); ?>" class="btn btn-secondary">Cancelar</a>
                    </div>
                </form>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pokedex\resources\views/pokemon_create.blade.php ENDPATH**/ ?>