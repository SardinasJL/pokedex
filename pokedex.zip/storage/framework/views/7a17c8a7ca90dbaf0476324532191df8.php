<?php $__env->startSection("content"); ?>

    <div class="container col-md-10">
        <div class="card">
            <div class="card-header">
                Dashboard
            </div>
            <div class="card-body">
                <h1>¡Bienvenido <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>!</h1>
                <h4>Actualmente se han registrado <?php echo e($cantidadTipos); ?> tipos de pokemons</h4>
                <h4>Actualmente se han registrado <?php echo e($cantidadPokemons); ?> pokemons</h4>
                <center>
                    <h5>Atrápalos a todos!</h5>
                </center>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pokedex\resources\views/dashboard.blade.php ENDPATH**/ ?>